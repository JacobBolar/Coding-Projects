package TCPServer;

import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.io.File;
import java.io.InputStream;

public class TCPServer
{
    public static void main(String argv[]) throws Exception
    {

        String clientSentence;

        Socket connectionSocket;

        BufferedReader fromClient;

        long totalTime = 0;

        //file to be recieved.
        String comparedFile = "test.txt";

        //name of copied file
        String outputFileName = "receivedFile";

        //new server socket
        ServerSocket serSock = new ServerSocket(6789);

        System.out.println("I am ready for any client side request.");

        //loop for 100 files
        for(int i=0; i<100; i++)
        {
            long fileTime = 0;
            long startTime = System.currentTimeMillis();

            //wait for client to accept
            connectionSocket = serSock.accept();

            System.out.println("I am starting to receive the " + comparedFile + " file for the " + (i+1) + "th time.");

            fromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));

            //creates a file that the received file will be written to
            PrintWriter out = new PrintWriter(outputFileName+(i+1)+ ".txt");

            int lineCounter = 0;

            //loops to see if client files ended
            while(true)
            {
                clientSentence = fromClient.readLine();

                if(clientSentence == null) break;

                out.println(clientSentence);
                lineCounter++;
                System.out.println("I have finished receiving the file for the: " + lineCounter + "nth time.");
            }


            out.close();

            //closes the server side
            connectionSocket.close();

            long endTime = System.currentTimeMillis();

            fileTime = endTime - startTime;

            System.out.println("The time in milliseconds to receive this file was " + Math.abs(fileTime) + " milliseconds.");

            totalTime += fileTime;

            System.out.println("I am finishing receiving the " + comparedFile + " file for the " + (i+1) + "th time.");
            System.out.println("\n");
        }
        System.out.println("I am done receiving files.");

        //closes the server socket because non persistent connection
        serSock.close();

        int failCount = 0;

        File serverFile = new File(comparedFile); //the file in the server side folder.

        //loop to compare server files to files recieved.
        for(int i=0; i<100; i++)
        {
            File clientFile = new File(outputFileName + (i+1) + ".txt");
            Scanner serverFileReader = new Scanner(serverFile);
            Scanner clientFileReader = new Scanner(clientFile);

            boolean passedTheTest;
            while(serverFileReader.hasNextLine() && clientFileReader.hasNextLine())
            {
                passedTheTest = serverFileReader.nextLine().equals(clientFileReader.nextLine());


                if(!(passedTheTest))
                {
                    System.out.println("File " + outputFileName+(i+1)+ ".txt has error");
                    failCount++;
                    break;
                }
            }
            serverFileReader.close();
            clientFileReader.close();
        }
        System.out.println("The failure rate is " + failCount + "/100");
        System.out.println("The average time to receive the file: " + (totalTime/100) + " milliseconds");
        System.out.println("I am done");
    }
}