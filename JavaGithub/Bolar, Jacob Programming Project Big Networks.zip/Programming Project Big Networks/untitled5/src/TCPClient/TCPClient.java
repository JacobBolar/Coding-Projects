package TCPClient;

import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;


public class TCPClient
{
    public static void main(String argv[]) throws Exception
    {
        //File Name
        String fileName = "test.txt";

        //finding file from string above.
        File clientFile = new File(fileName); //creating the file variable

        long totalTime = 0; //variable for the total time

        //loop for 100 file sends
        for (int i=0; i<100; i++)
        {
            long fileTime = 0;

            long startTime = System.currentTimeMillis();

            //scanner for sending file
            Scanner clientFileReader = new Scanner(clientFile);

            //client socket to server
            Socket clientSocket = new Socket("216.186.182.193", 6789);

            //display the IP address
            System.out.println("I am connecting to the Server side: " + clientSocket.getLocalAddress());

            System.out.println("\nI am sending file " + clientFile + " for the " + (i+1) + "th time");

            System.out.println("File transmission start time: " + startTime);

            //creates output stream that will be used to send data to the server
            DataOutputStream toServer = new DataOutputStream(clientSocket.getOutputStream());

            //reads in the file and replaces the "\n" dropped by the nextLine() function.
            while(clientFileReader.hasNextLine())
            {
                toServer.writeBytes(clientFileReader.nextLine() + "\n");
            }

            //closes the file
            clientFileReader.close();

            //closes the client socket because its non persistant
            clientSocket.close();

            long endTime = System.currentTimeMillis();

            System.out.println("File transmission end time: " + endTime);

            fileTime = endTime - startTime;

            System.out.println("The time used in milliseconds to send " + fileTime + " milliseconds");

            totalTime += fileTime;

            System.out.println("The " + clientFile + " file sent " + (i+1) + " times");

            System.out.println("\n");
        }
        System.out.println("The total time to send the file 100 times: " + totalTime + " milliseconds"); //displays the total time
        System.out.println("The average time to send the file: " + totalTime/100 + "." + totalTime%100 + " milliseconds"); //displays the average
        System.out.println("I am done");
    }
}