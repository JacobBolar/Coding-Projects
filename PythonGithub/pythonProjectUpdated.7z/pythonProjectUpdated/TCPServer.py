#Improrting socket module
from socket import *

#setting server name and port
serverName="localhost"
serverPort=12000

#creating server socket, SOCK_STREAM identifies socket as TCP and attaches the server socket to the server. variables initalized above
serverSocket=socket(AF_INET,SOCK_STREAM)
serverSocket.bind((serverName,serverPort))

#Opens the connection for a client to talk to.
serverSocket.listen(1)
print("Server is ready to recieve")

#While loop to keep server on
while True:
    #accepts a connection to the server socket
    connectionSocket,clientAddress=serverSocket.accept()


    #Recieving message from client and prints the message from the client address
    messageFromClientBytes=connectionSocket.recv(1024)
    while messageFromClientBytes != "bye":
        print(messageFromClientBytes,"from",clientAddress)

    #takes the message and makes it all upper case and sends the upper-cased message back to client
        messageToClientBytes=messageFromClientBytes.upper()
        connectionSocket.send(messageToClientBytes)
        messageFromClientBytes = connectionSocket.recv(1024)

    connectionSocket.close()



