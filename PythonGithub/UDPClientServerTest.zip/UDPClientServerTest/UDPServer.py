from socket import *

serverName = "localhost"
serverPort = 12000

serverSocket = socket(AF_INET, SOCK_DGRAM)

serverSocket.bind((serverName, serverPort))

print(" The server is ready to recieve!")



while True:
    messageFromClient, clientAddress = serverSocket.recvfrom(1024)

    messageToClient = messageFromClient.upper()

    serverSocket.sendto(messageToClient, clientAddress)
