from socket import *

#Server Name and Port
serverName = "localhost"
serverPort = 12000

#Creating UDP Socket
clientSocket = socket(AF_INET, SOCK_DGRAM)

#Inputting a lower case sentence.  We are going to have the UDPSever send back all upper case
message = input('Input lowercase sentence: ')


# messageBytes = str.encode(message), if you wanted to make the variable into bytes before sendTo below.
#encoding to bytes is required for sockets.

#Sends a byte encoded message to a designated server name and port.  Variables above.
clientSocket.sendto(str.encode(message), (serverName, serverPort))

modifiedMessage, serverAddress = clientSocket.recvfrom(1024)

print(bytes.decode(modifiedMessage))

clientSocket.close()