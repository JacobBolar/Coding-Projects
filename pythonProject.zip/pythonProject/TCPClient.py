#importing socket module
from socket import *

#identifying server that we want to connect to
serverName="localhost"
serverPort=12000

#Making socket, TCP connection because of SOCK_STREAM
clientSocket=socket(AF_INET,SOCK_STREAM)

#Connecting to server identified by variables above
clientSocket.connect((serverName,serverPort))

#input a message to encode into bytes and sending it to server
message=input("Enter a message: ")
messageBytes=str.encode(message) #converting message to bytes
clientSocket.send(messageBytes)

#Recieves message from server, identifies where it came from and prints message, closes socket
messageFromServerBytes=clientSocket.recv(1024)
print(bytes.decode(messageFromServerBytes),"from",(serverName,serverPort))
clientSocket.close()
