﻿using System;
using System.Collections.Generic;

namespace StarterGame
{
    public class GameWorld
    {
        private static GameWorld _instance = null;

        public static GameWorld Instance
        {
            get
            {
                
                //lazy initializer
                if(_instance == null)
                {
                    _instance = new GameWorld();
                }
                return _instance;
                
            }
        }

        private Room _entrance;
        //get is read only
        public Room Entrance { get { return _entrance;  } }

        private Room _exit;
        public Room Exit { get { return _exit;  } }

        private Room _magicRoom;
        public Room MagicRoom { get { return _magicRoom; } }

        private Room _entertainmentRoom;
        public Room EntertainmentRoom { get { return _entertainmentRoom; } }

        private Room _toEntertainmentRoom;
        public Room ToEntertainmentRoom { get { return _toEntertainmentRoom; } }

        private Dictionary<Room, WorldChange> worldEvent;

        private GameWorld()
        {
            worldEvent = new Dictionary<Room, WorldChange>();
            CreateWorld();
            NotificationCenter.Instance.AddObserver("", PlayerDidExitRoom);
            NotificationCenter.Instance.AddObserver("", PlayerWillExitRoom);
           // NotificationCenter.Instance.AddObserver("GameClockTick", GameClockTick);
        }

        public void PlayerWillExitRoom(Notification notification)
        {
            Player player = (Player)notification.Object;
            if(player.CurrentRoom == _exit)
            {
                player.OutputMessage("Player left the exit room");
            }
            //player.OutputMessage("Player will exit room " + player.CurrentRoom.Tag);
        }

        public void PlayerDidExitRoom(Notification notification)
        {
            Player player = (Player)notification.Object;
            WorldChange we = null;
            worldEvent.TryGetValue(player.CurrentRoom, out we);
            if (we != null)
            {
                we.Execute();
            }
            // if (player.CurrentRoom == _magicRoom)
            // {
            //     _toEntertainmentRoom.SetExit("west", _entertainmentRoom);
            //     _entertainmentRoom.SetExit("East", _toEntertainmentRoom);
            //     player.OutputMessage("You have changed the world!");
            // }
            //player.OutputMessage("Player will exit room " + player.CurrentRoom.Tag);

        }

        public void GameClockTick(Notification notification)
        {
            Console.WriteLine("Clock Tick!00");
        }
        private void CreateWorld()
        {
            Room outside = new Room("outside the main entrance of the university");
            Room cctparking = new Room("in the parking lot at CCT");
            Room boulevard = new Room("on the boulevard");
            Room universityParking = new Room("in the parking lot at University Hall");
            Room parkingDeck = new Room("in the parking deck");
            Room cct = new Room("in the CCT building");
            Room theGreen = new Room("in the green in from of Schuster Center");
            Room universityHall = new Room("in University Hall");
            Room schuster = new Room("in the Schuster Center");
            Room davidson = new Room("in the Davidson Center");
            Room greekCenter = new Room("in the Greek Center");
            Room clockTower = new Room("at the Clock Tower");
            Room woodall = new Room("in the Woodall Hall");

            //Door door = new Door(outside, boulevard);
            // outside.SetExit("west", boulevard);
            // boulevard.SetExit("east", outside);
            Door door = Door.connectRooms(cctparking, boulevard, "south", "north");
            boulevard.SetExit("south", door);
            cctparking.SetExit("west", door);
            
            door = Door.connectRooms(cctparking, cct, "north", "east");
            cctparking.SetExit("north", door);
            cct.SetExit("east", door);
            
            door = Door.connectRooms(theGreen, schuster, "east", "west");
            theGreen.SetExit("west", door);
            schuster.SetExit("east", door);
            
            door = Door.connectRooms(universityParking, boulevard, "north", "south");
            boulevard.SetExit("north", door);
            universityParking.SetExit("south", door);
            
            door = Door.connectRooms(schuster, universityHall, "north", "south");
            schuster.SetExit("north", door);
            universityHall.SetExit("south", door);
          
            door = Door.connectRooms(cct, schuster, "south", "north");
            cct.SetExit("north", door);
            schuster.SetExit("south", door);
            
            door = Door.connectRooms(theGreen, boulevard, "west", "east");
            theGreen.SetExit("east", door);
            boulevard.SetExit("west", door);
            
            door = Door.connectRooms(universityHall, universityParking, "west", "east");
            universityHall.SetExit("east", door);
            universityParking.SetExit("west", door);
            
            door = Door.connectRooms(universityParking, parkingDeck, "south", "north");
            universityParking.SetExit("north", door);
            parkingDeck.SetExit("south", door);
            
            door = Door.connectRooms(davidson, clockTower, "east", "west");
            davidson.SetExit("west", door);
            clockTower.SetExit("east", door);
            
            door = Door.connectRooms(clockTower, greekCenter, "south", "north");
            clockTower.SetExit("north", door);
            greekCenter.SetExit("south", door);
          
            door = Door.connectRooms(clockTower, woodall, "north", "south");
            clockTower.SetExit("south", door);
            woodall.SetExit("north", door);
            
            
            _entrance = outside;
            _exit = cct;
            _magicRoom = cctparking;
            //_entertainmentRoom = davidson;
            WorldChange we = new WorldChange(schuster, davidson, "west", "east");
            worldEvent[cctparking] = we;
        }
        
        private interface WorldEvent
        {
            void Execute();
        }

        private class WorldChange : WorldEvent
        {
            public Room RoomA { get; set; }
            public Room RoomB { get; set; }
            public string AtoB { get; set; }
            public string BtoA { get; set; }

            public WorldChange(Room roomA, Room roomB, string aToB, string bToA)
            {
                RoomA = roomA;
                RoomB = roomB;
                AtoB = aToB;
                BtoA = bToA;
            }

            public void Execute()
            {
                Door.connectRooms(RoomA, RoomB, AtoB, BtoA);
            }
        }
    }
}
