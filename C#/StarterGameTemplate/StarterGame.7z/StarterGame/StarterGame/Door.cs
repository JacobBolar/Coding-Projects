﻿namespace StarterGame
{
    public class Door
    {
        private Room _room1;
        private Room _room2;

        public Door(Room room1, Room room2)
        {
            _room1 = room1;
            _room2 = room2;
        }

        public Room OtherRoom(Room thisRoom)
        {
            if (thisRoom == _room1)
            {
                return _room2;
            }
            else
            {
                return _room1;
            }
            //return thisRoom == _room1 ? _room2: _room2;
        }

        public static Door connectRooms(Room fromRoom, Room toRoom, string fromTo, string toFrom)
        {
            Door door = new Door(fromRoom, toRoom);
            fromRoom.SetExit(fromTo, door);
            toRoom.SetExit(toFrom, door);
            return door;
        }
    }
}