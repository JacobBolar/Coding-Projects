﻿using System.Collections;
using System.Collections.Generic;
using System;

namespace StarterGame
{
    public class Player
    {
        private Room _currentRoom = null;
        public Room CurrentRoom
        {
            get
            {
                return _currentRoom;
            }
            set
            {
                _currentRoom = value;
            }
        }

        public Player(Room room)
        {
            _currentRoom = room;
        }

        public void WalkTo(string direction)
        {
            Room nextRoom = this._currentRoom.GetExit(direction, out TODO);
            if (nextRoom != null)
            {
                Notification notification = new Notification("PlayerWillExitRoom", this);
                notification = new Notification("PlayerDidExitRoom", this);
                NotificationCenter.Instance.PostNotification(notification);
                this._currentRoom = nextRoom;
                NotificationCenter.Instance.PostNotification(notification);
                this.OutputMessage("\n" + this._currentRoom.Description());
            }
            else
            {
                this.OutputMessage("\nThere is no door on " + direction);
            }
        }

        public void OutputMessage(string message)
        {
            Console.WriteLine(message);
        }
    }

}
